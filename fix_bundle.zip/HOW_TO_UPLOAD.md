# Fix Bundle 업로드 가이드

이 폴더에 있는 파일들:
- `intbig.h` — 수정된 새 버전 (전체 파일 통째로)
- `flags.cmake` — 수정된 새 버전 (전체 파일 통째로)
- `PATCH.diff` — unified diff 형식 (git apply 또는 참고용)
- `HOW_TO_UPLOAD.md` — 본 파일

대상 repo: **https://github.com/yhwkorea/compact-SQIsign**

---

## 방법 A — GitHub 웹 UI (git 없이도 가능, 가장 빠름)

각 파일에 대해 동일 절차:

### A-1. `intbig.h` 업로드

1. 브라우저에서 https://github.com/yhwkorea/compact-SQIsign/blob/main/src/quaternion/ref/generic/include/intbig.h 접속
2. 우측 상단 **연필 아이콘** (Edit this file) 클릭
3. 화면의 코드 **전체 선택 (Ctrl+A) 후 삭제**
4. 본 폴더의 `intbig.h` 를 메모장으로 열어서 **전체 복사 (Ctrl+A → Ctrl+C)**
5. 빈 GitHub 편집창에 **붙여넣기 (Ctrl+V)**
6. 페이지 하단 **Commit changes** 클릭
7. Commit message:
   ```
   fix(intbig): SQISIGN_VARIANT token comparison via concatenation

   기존 `#if SQISIGN_VARIANT == SQISIGN_LVL1` 가 token 비교라 모든 레벨
   에서 첫 분기 (LVL1, IBZ_LIMBS=110) 만 매치 → L3 precomp 파일이
   168 limbs 가정으로 overflow 'excess elements in array initializer'.
   token concatenation 으로 per-level 직접 선택하게 수정.
   ```
8. **Commit directly to the main branch** 선택 → **Commit changes** 클릭

### A-2. `flags.cmake` 업로드

같은 절차로 https://github.com/yhwkorea/compact-SQIsign/blob/main/.cmake/flags.cmake 에 적용.

Commit message:
```
fix(flags): GCC 14 false-positive warnings excluded from -Werror

mp.c:297 maybe-uninitialized (mp_inv_2e 의 x[0] 직전 mp_add 추적 실패)
apps/fuzz_verify.c:26 format-truncation (snprintf %s.bin 안전한 길이)
다른 strict 옵션은 모두 유지.
```

---

## 방법 B — git CLI 로 PR 만들기 (정석)

git 설치된 컴퓨터라면:

```bash
git clone https://github.com/yhwkorea/compact-SQIsign.git
cd compact-SQIsign
git checkout -b fix/build-errors

# 수정 파일 덮어쓰기
cp /path/to/fix_bundle/intbig.h src/quaternion/ref/generic/include/intbig.h
cp /path/to/fix_bundle/flags.cmake .cmake/flags.cmake

git add src/quaternion/ref/generic/include/intbig.h .cmake/flags.cmake
git commit -m "fix: build errors with standard cmake/make commands

intbig.h:
  SQISIGN_VARIANT token comparison was evaluating as 0 == 0 (all branches
  matched, IBZ_LIMBS always 110). Replaced with token concatenation so
  per-level width is selected correctly.

flags.cmake:
  GCC 14 false-positives in mp.c:297 (maybe-uninitialized) and
  apps/fuzz_verify.c:26 (format-truncation) excluded from -Werror.
  Other strict options preserved.

Verified: standard 'cmake / make / make test' now succeeds. Tests 1-18
(quaternion / gf / curve / ec / biextension / basis_gen, all 3 levels)
PASS. Tests 19-36 still fail on Windows MinGW (Windows-specific
SegFault / 0xC0000409); needs Linux/WSL for full e2e validation.
"

git push -u origin fix/build-errors
```

→ GitHub 페이지 가면 "Compare & pull request" 노란 띠 → 클릭 → PR title + description 작성 → 1저자 review 요청 → approve 후 main 으로 merge.

---

## 또는 PATCH.diff 만 사용 (git apply)

```bash
cd compact-SQIsign
git checkout -b fix/build-errors
git apply /path/to/fix_bundle/PATCH.diff
git add -A
git commit -m "..."
git push -u origin fix/build-errors
```

(PATCH.diff 의 index 해시는 placeholder 라 `git apply --3way` 또는 `--reject` 옵션 추가 필요할 수 있음. 못 적용되면 방법 B 의 cp 방식 권장.)

---

## 검증 (다른 컴퓨터에서 빌드 확인)

push 후 1저자 (또는 본인) 가 fresh clone 하고:

```bash
git clone https://github.com/yhwkorea/compact-SQIsign.git
cd compact-SQIsign
mkdir -p build
cd build
cmake -DSQISIGN_BUILD_TYPE=ref ..
make
make test
```

→ Linux/WSL 환경에서 `make test` 36/36 PASS 가 목표 (Windows 에서는 19-36 깸).

---

## 다음 단계 (1저자 review 후)

3저자 로컬 (`C:\sqi\base\`) 에 있는 MLLL 통합 작업물도 PR 으로 push:
- PR1: GCD 변종 알고리즘 (`ibz_gcdext_alt.c`) + 테스트
- PR2: 4×4 det 변종 (`ibz_det_alt.c`, `ibz_det_bareiss.c`) + 테스트
- PR3: MLLL 본체 (`mlll.c`, `mlll_gram.c`, `mlll_internals.h`)
- PR4: macro alias 라우팅 (`quaternion.h` + CMakeLists `SQISIGN_USE_MLLL_GRAM`)
- PR5: `lll_applications_mlll_gram.c` (4 MLLL_GRAM lideal 함수)
- PR6: `REPORT_TO_FIRST_AUTHOR.md` (페이퍼 §5 분석 갭 보고서)

순차 push, 각 PR 별로 1저자 review 후 main merge.
